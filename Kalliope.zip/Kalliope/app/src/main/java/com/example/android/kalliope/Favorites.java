package com.example.android.kalliope;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class Favorites extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_item);

        // Create a list of songs
        ArrayList<Song> songs = new ArrayList<Song>();
        songs.add(new Song("Artic Monkeys", "Suck it and see"));
        songs.add(new Song("Artic Monkeys", "When the sun goes down"));
        songs.add(new Song("Lana del Rey", "Blue jeans"));
        songs.add(new Song("Lana del Rey", "Born to die"));
        songs.add(new Song("Mumford and Sons", "I will wait"));
        songs.add(new Song("Mumford and Sons", "White blank page"));
        songs.add(new Song("Smashing Pumpkins", "By Starlight"));
        songs.add(new Song("Smashing Pumpkins", "Zero"));

        // Construct the data source
        ArrayList<Song> arrayOfSongs = new ArrayList<Song>();

        // Create the adapter to convert the array to views
        SongAdapter adapter = new SongAdapter(this, arrayOfSongs);

        // Attach the adapter to a ListView
        ListView listView = (ListView) findViewById(R.id.list_item);
        listView.setAdapter(adapter);
    }
}