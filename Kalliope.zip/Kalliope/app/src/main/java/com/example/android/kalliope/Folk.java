package com.example.android.kalliope;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;

public class Folk extends AppCompatActivity {
    ImageButton play;

    @Override
    public void setContentView(View view) {
        super.setContentView(R.layout.song_list);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);

        // Create a list of songs
        ArrayList<Song> songs = new ArrayList<>();

        songs.add(new Song("Mumford and Sons", "I will wait", "FOLK"));
        songs.add(new Song("Mumford and Sons", "White blank page", "FOLK"));

        // Create the adapter to convert the array to views
        SongAdapter adapter = new SongAdapter(this, songs);

        // Attach the adapter to a ListView
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}