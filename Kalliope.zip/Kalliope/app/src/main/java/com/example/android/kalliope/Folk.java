package com.example.android.kalliope;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import java.util.ArrayList;

public class Folk extends AppCompatActivity {

    ImageButton play = findViewById(R.id.play_image_button);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);

        // Create a list of songs
        ArrayList<Song> song = new ArrayList<>();
        song.add(new Song("Mumford and Sons", "I will wait"));
        song.add(new Song("Mumford and Sons", "White blank page"));

        // Create the adapter to convert the array to views
        SongAdapter adapter = new SongAdapter(this, song);

        // Attach the adapter to a ListView
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);


        // The code in this method will be executed when the play button is clicked
        play.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Clicking on the button will first open the Now Playing Activity
                Intent playIntent = new Intent(Folk.this, NowPlaying.class);
                // Start the new activity
                startActivity(playIntent);
            }
        });
    }
}


