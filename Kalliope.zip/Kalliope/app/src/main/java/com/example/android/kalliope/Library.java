package com.example.android.kalliope;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class Library extends AppCompatActivity {

    // Set the view for this method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);

        // Create a list of songs
        ArrayList<Song> songs = new ArrayList<>();
        songs.add(new Song("Arctic Monkeys", "Suck it and see", "ROCK"));
        songs.add(new Song("Arctic Monkeys", "When the sun goes down", "ROCK"));
        songs.add(new Song("Lana del Rey", "Blue jeans", "POP"));
        songs.add(new Song("Lana del Rey", "Born to die", "POP"));
        songs.add(new Song("Mumford and Sons", "I will wait", "FOLK"));
        songs.add(new Song("Mumford and Sons", "White blank page", "FOLK"));
        songs.add(new Song("Smashing Pumpkins", "By Starlight", "ROCK"));
        songs.add(new Song("Smashing Pumpkins", "Zero", "ROCK"));

        // Create the adapter to convert the array to views
        SongAdapter adapter = new SongAdapter(this, songs);

        // Attach the adapter to a ListView
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
