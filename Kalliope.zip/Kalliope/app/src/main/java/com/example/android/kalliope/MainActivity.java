package com.example.android.kalliope;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    // Set the content of the activity to use the activity_main.xml layout file
    setContentView(R.layout.activity_main);

    // Find the View that shows the Library category
        TextView library = (TextView) findViewById(R.id.favorites);

        // Set a click listener on that View
        library.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Library category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FavoritesActivity}
                Intent libraryIntent = new Intent(MainActivity.this, Library.class);

                // Start the new activity
                startActivity(libraryIntent);
            }
        });

        // Find the View that shows the Now Playing category
        TextView nowPlaying = (TextView) findViewById(R.id.nowPlaying);

        // Set a click listener on that View
        nowPlaying.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Now PLaying category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link NowPlayingActivity}
                Intent nowPlayingIntent = new Intent(MainActivity.this, NowPlaying.class);

                // Start the new activity
                startActivity(nowPlayingIntent);
            }
        });

        // Find the View that shows the Search by Artist category
        TextView searchByArtist = (TextView) findViewById(R.id.searchByArtist);

        // Set a click listener on that View
        searchByArtist.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Search By Artist category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link SearchByArtistActivity}
                Intent searchByArtistIntent = new Intent(MainActivity.this, SearchByArtist.class);

                // Start the new activity
                startActivity(searchByArtistIntent);
            }
        });

        // Find the View that shows the Search By Genre category
        final TextView searchByGenre = (TextView) findViewById(R.id.searchByGenre);

        // Set a click listener on that View
        searchByGenre.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Search By Genre category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link SearchByGenreActivity}
                Intent searchByGenreIntent = new Intent(MainActivity.this, SearchByGenre.class);

                // Start the new activity
                startActivity(searchByGenreIntent);
            }
        });
    }
}
