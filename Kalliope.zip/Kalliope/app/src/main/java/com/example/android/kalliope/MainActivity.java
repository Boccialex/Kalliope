package com.example.android.kalliope;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    // Set the content of the activity to use the activity_main.xml layout file
    setContentView(R.layout.activity_main);

    // Find the View that shows the Library category
        TextView library = (TextView) findViewById(R.id.library);

        // Set a click listener on that View
        library.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Library category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FavoritesActivity}
                Intent libraryIntent = new Intent(MainActivity.this, Library.class);

                // Start the new activity
                startActivity(libraryIntent);
            }
        });


        // Find the View that shows the Search By Genre category
        final TextView searchByGenre = (TextView) findViewById(R.id.searchByGenre);

        // Set a click listener on that View
        searchByGenre.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Search By Genre category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link SearchByGenreActivity}
                Intent searchByGenreIntent = new Intent(MainActivity.this, SearchByGenre.class);

                // Start the new activity
                startActivity(searchByGenreIntent);
            }
        });
    }
}