package com.example.android.kalliope;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class Pop extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);

        // Create a list of songs
        ArrayList<Song> song = new ArrayList<>();
        song.add(new Song("Lana del Rey", "Blue jeans"));
        song.add(new Song("Lana del Rey", "Born to die"));

        // Create the adapter to convert the array to views
        SongAdapter adapter = new SongAdapter(this, song);

        // Attach the adapter to a ListView
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
