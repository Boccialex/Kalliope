package com.example.android.kalliope;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class Rock extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set a view for this method
        setContentView(R.layout.song_list);

        // Create a list of songs
        ArrayList<Song> songs = new ArrayList<>();

        songs.add(new Song("Artic Monkeys", "Suck it and see", "ROCK"));
        songs.add(new Song("Artic Monkeys", "When the sun goes down", "ROCK"));
        songs.add(new Song("Smashing Pumpkins", "By Starlight", "ROCK"));
        songs.add(new Song("Smashing Pumpkins", "Zero", "Rock"));

        // Create the adapter to convert the array to views
        SongAdapter adapter = new SongAdapter(this, songs);

        // Attach the adapter to a ListView
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
