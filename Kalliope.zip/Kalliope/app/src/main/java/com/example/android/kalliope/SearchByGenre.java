package com.example.android.kalliope;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class SearchByGenre extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_by_genre);

        // Find the View that shows the Library category
        TextView folk = (TextView) findViewById(R.id.folk);

        // Set a click listener on that View
        folk.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Library category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FavoritesActivity}
                Intent folkIntent = new Intent(SearchByGenre.this, Folk.class);

                // Start the new activity
                startActivity(folkIntent);
            }
        });

        // Find the View that shows the Library category
        TextView pop = (TextView) findViewById(R.id.pop);

        // Set a click listener on that View
        pop.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Library category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FavoritesActivity}
                Intent popIntent = new Intent(SearchByGenre.this, Pop.class);

                // Start the new activity
                startActivity(popIntent);
            }
        });

        // Find the View that shows the Library category
        TextView rock = (TextView) findViewById(R.id.rock);

        // Set a click listener on that View
        rock.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Library category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FavoritesActivity}
                Intent rockIntent = new Intent(SearchByGenre.this, Rock.class);

                // Start the new activity
                startActivity(rockIntent);
            }
        });

    }
}