package com.example.android.kalliope;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class SearchByGenre extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_by_genre);
    }

    public static class SongAdapter extends ArrayAdapter<Song> {
        public SongAdapter(Context context, ArrayList<Song> song) {
            super(context, 0, song);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
                Song song = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            View listItemView = convertView;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(
                        R.layout.list_item, parent, false);
            }

            // Lookup view for data population
            TextView artists = (TextView) convertView.findViewById(R.id.artists_text_view);
            TextView musicName = convertView.findViewById(R.id.musicName_text_view);

            // Populate the data into the template view using the data object
            artists.setText(song.artists);
            musicName.setText(song.musicName);

            // Return the completed view to render on screen
            return convertView;
        }
    }
}
