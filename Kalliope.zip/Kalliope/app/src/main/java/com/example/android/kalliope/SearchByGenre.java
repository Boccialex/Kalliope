package com.example.android.kalliope;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;


public class SearchByGenre extends AppCompatActivity {

    // This method will open 3 other different activities: Folk, Pop, Rock
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the content of the activity to use the search_by_genre.xml layout file
        setContentView(R.layout.activity_search_by_genre);

        // Find the View that shows the Folk category
        TextView folk = findViewById(R.id.folk);

        // Set a click listener on that View
        folk.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Library category is clicked on.

            public void onClick(View view) {
                // Create a new intent to open the {@link FolkActivity}
                Intent folkIntent = new Intent(SearchByGenre.this, Folk.class);

                // Start the new activity
                startActivity(folkIntent);
            }
        });


        // Find the View that shows the Pop category
        TextView pop = findViewById(R.id.pop);

        // Set a click listener on that View
        pop.setOnClickListener(new View.OnClickListener()

        {
            // The code in this method will be executed when the Search By Genre category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link PopActivity}
                Intent popIntent = new Intent(SearchByGenre.this, Pop.class);

                // Start the new activity
                startActivity(popIntent);
            }
        });

        // Find the View that shows the Rock category
        TextView rock = findViewById(R.id.rock);

        // Set a click listener on that View
        rock.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Search By Genre category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link RockActivity}
                Intent rockIntent = new Intent(SearchByGenre.this, Rock.class);

                // Start the new activity
                startActivity(rockIntent);
            }
        });
    }
}
