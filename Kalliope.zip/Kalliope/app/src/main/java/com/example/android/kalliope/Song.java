package com.example.android.kalliope;

public class Song {
    public String artists;
    public String musicName;

    /**
     * Create a new {@link Song} object.
     *  @param artists is the current context (i.e. Activity) that the adapter is being created in.
     * @param musicName is the list of {@link Song}s to be displayed.
     */
    public Song(String artists, String musicName) {
        this.artists = artists;
        this.musicName = musicName;
    }

    /**
     * Get the the artist's name
     */
    public String getArtists () {
        return artists;
    }

    /**
     * Get the song's name
     */
    public String getMusicName() {
        return musicName;
    }
}
