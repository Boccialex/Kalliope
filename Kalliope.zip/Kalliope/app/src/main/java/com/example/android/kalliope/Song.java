package com.example.android.kalliope;

public class Song {
    public String artists;
    public String musicName;
    public String genre;

    /**
     * Create a new {@link Song} object.
     *
     * @param artists   is the current context (i.e. Activity) that the adapter is being created in.
     * @param musicName is the list of {@link Song}s to be displayed.
     * @param genre     is the kind of genre that applies to a specific song
     */

    public Song(String artists, String musicName, String genre) {
        this.artists = artists;
        this.musicName = musicName;
        this.genre = genre;
    }

    /**
     * Methods to get the artist's and music name, the genre and the button to play the song
     */
    // Get the artist's name
    public String getArtists() {
        return artists;
    }

    // Get the music's name
    public String getMusicName() {
        return musicName;
    }

    // Get the genre
    public String getGenre() {
        return genre;
    }
}

