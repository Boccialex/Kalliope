package com.example.android.kalliope;

class Song {
    /** Artist's name */
    private String mArtists;

    /** Name of the song */
    private String mMusicName;

    /**
     * Create a new Song object.
     *
     * @param artists is the name of the song's author
     * @param musicName is the proper name of the song
     */
    public Song(String artists, String musicName) {
        mArtists = artists();
        mMusicName = musicName();
    }


    /**
     * Get the the artist's name
     */
    public String getArtists() {
        return mArtists;
    }

    /**
     * Get the song's name
     */
    public String getMusicName() {
        return mMusicName();
    }
}
