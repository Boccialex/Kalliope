package com.example.android.kalliope;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SongAdapter extends ArrayAdapter<Song> {

    public SongAdapter(Context context, ArrayList<Song> songs) {
        super(context, 0, songs);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Get the data item for this position
        Song songs = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        // Lookup view for data population
        final TextView artists = convertView.findViewById(R.id.artists_text_view);
        final TextView musicName = convertView.findViewById(R.id.musicName_text_view);
        final TextView genre = convertView.findViewById(R.id.genre_text_view);
        final ImageButton play = convertView.findViewById(R.id.play_image_button);

        // Populate the data into the template view using the data object
        assert songs != null;
        artists.setText(songs.artists);
        musicName.setText(songs.musicName);
        genre.setText(songs.genre);
        play.setImageResource(R.drawable.play_image_view);

        // Return the completed view to render on screen
        return convertView;

        // Set a click listener on that View
        play.setOnClickListener(new View.OnClickListener() {

            // The code in this method will be executed when the Library category is clicked on.

            public void onClick(View view) {
                // Displays the chosen song in a toast message
                String playingSong = getResources().getString(R.string.toast_now_playing) + artists + " " + " " + musicName;
                Toast.makeText(this, playingSong, Toast.LENGTH_LONG).show();
                }
        });
    }
    }
