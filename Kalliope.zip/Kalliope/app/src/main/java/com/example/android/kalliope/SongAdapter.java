package com.example.android.kalliope;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SongAdapter extends ArrayAdapter<Song> {

    public SongAdapter(Context context, ArrayList<Song> songs) {
        super(context, 0, songs);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Get the data item for this position
        final Song songs = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        // Lookup view for data population
        final TextView artists = convertView.findViewById(R.id.artists_text_view);
        final TextView musicName = convertView.findViewById(R.id.musicName_text_view);
        final TextView genre = convertView.findViewById(R.id.genre_text_view);
        final ImageButton play = convertView.findViewById(R.id.play_image_button);
        final ImageButton home = convertView.findViewById(R.id.home_image_button);

        // Populate the data into the template view using the data object
        assert songs != null;
        artists.setText(songs.artists);
        musicName.setText(songs.musicName);
        genre.setText(songs.genre);
        play.setBackgroundResource(R.drawable.play_image_view);
        home.setBackgroundResource(R.drawable.icon_name);


        // Set a click listener on the Play Image button
        play.setOnClickListener(new View.OnClickListener() {

            // The code in this method will be executed when the Play button is clicked on
            public void onClick(View view) {

                // Displays the chosen song in a toast message
                String playingSong = getContext().getString(R.string.toast_now_playing) + "  " + songs.artists + "  - \" " + songs.musicName + " \" ";
                Toast.makeText(getContext(), playingSong, Toast.LENGTH_LONG).show();
            }
        });

        // Set a click listener on the Home Image button
        home.setOnClickListener(new View.OnClickListener() {

            // The code in this method will be executed when the home button is clicked on
            public void onClick(View view) {
                // Create a new intent to open the {@link MainActivity}
                Intent homeIntent = new Intent(view.getContext(), MainActivity.class);

                // Start the Main Activity
               view.getContext().startActivity(homeIntent);
            }
        });

        // Return the completed view to render on screen
        return convertView;
    }
}
